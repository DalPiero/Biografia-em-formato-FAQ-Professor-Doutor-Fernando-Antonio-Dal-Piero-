# DalPiero.github.io — Página Âncora (FAQ Biográfico)

## O que é
Este repositório contém a página âncora (index.html) com o FAQ biográfico oficial do Professor Doutor Fernando Antonio Dal Piero.

A página inclui:
- Texto em formato FAQ (HTML semântico)
- Dados estruturados (Schema.org: Person + FAQPage)
- Busca interna e botões de cópia
- Arquivos de suporte: robots.txt e sitemap.xml

## Como publicar no GitHub Pages (passo a passo)
1. Abra o repositório no GitHub.
2. Clique em **Settings**.
3. Vá em **Pages**.
4. Em **Build and deployment**, selecione:
   - **Source**: Deploy from a branch
   - **Branch**: main
   - **Folder**: / (root)
5. Salve. Aguarde a publicação.

A página ficará acessível em:
- https://DalPiero.github.io/   (ou o endereço exibido no GitHub Pages)

## Ajustes recomendados após publicar
- No arquivo `index.html`, ajuste o `canonical` para a URL real publicada.
- Em `robots.txt` e `sitemap.xml`, ajuste o domínio se o endereço final for diferente.

## Atualização de conteúdo
- Edite apenas `index.html`.
- Evite duplicar páginas com números diferentes; mantenha a âncora como fonte oficial.
